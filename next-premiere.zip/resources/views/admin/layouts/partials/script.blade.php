  <!--end::App Wrapper-->
  <!--begin::Script-->
  <script>
      document.getElementById('currentYear').textContent = new Date().getFullYear();
  </script>
  <!--begin::Third Party Plugin(OverlayScrollbars)-->
  <script src="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/browser/overlayscrollbars.browser.es6.min.js"
      crossorigin="anonymous"></script>
  <!--end::Third Party Plugin(OverlayScrollbars)--><!--begin::Required Plugin(popperjs for Bootstrap 5)-->
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" crossorigin="anonymous">
  </script>
  <!--end::Required Plugin(popperjs for Bootstrap 5)--><!--begin::Required Plugin(Bootstrap 5)-->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.min.js" crossorigin="anonymous"></script>
  <!--end::Required Plugin(Bootstrap 5)--><!--begin::Required Plugin(AdminLTE)-->
  <script src="{{ asset('assets/js/adminlte.js') }}"></script>
  <!--end::Required Plugin(AdminLTE)-->
  <!--begin::OverlayScrollbars Configure-->
  <script>
      const SELECTOR_SIDEBAR_WRAPPER = '.sidebar-wrapper';
      const Default = {
          scrollbarTheme: 'os-theme-light',
          scrollbarAutoHide: 'leave',
          scrollbarClickScroll: true,
      };
      document.addEventListener('DOMContentLoaded', function() {
          const sidebarWrapper = document.querySelector(SELECTOR_SIDEBAR_WRAPPER);

          // Disable OverlayScrollbars on mobile devices to prevent touch interference
          const isMobile = window.innerWidth <= 992;

          if (
              sidebarWrapper &&
              OverlayScrollbarsGlobal?.OverlayScrollbars !== undefined &&
              !isMobile
          ) {
              OverlayScrollbarsGlobal.OverlayScrollbars(sidebarWrapper, {
                  scrollbars: {
                      theme: Default.scrollbarTheme,
                      autoHide: Default.scrollbarAutoHide,
                      clickScroll: Default.scrollbarClickScroll,
                  },
              });
          }
      });
  </script>
  <!--end::OverlayScrollbars Configure-->
  <!--begin::Charts follow the colour mode-->
  <script>
      // ApexCharts draws light-theme tooltips and axis text unless told otherwise,
      // which is unreadable in dark mode (#6105). Give it the page's colour mode as
      // a global default before any chart is created — this runs before the chart
      // pages' own scripts — and keep every chart that has a `chart.id` in step
      // when the mode changes (ColorMode, the OS in auto mode, or your own code).
      (() => {
          'use strict';
          const mode = () =>
              document.documentElement.getAttribute('data-bs-theme') === 'dark' ? 'dark' : 'light';
          // `Apex` is ApexCharts' global-options object; it must exist before the library loads.
          // theme.mode also sets a dark chart background — keep the card's instead.
          // eslint-disable-next-line unicorn/no-global-object-property-assignment
          globalThis.Apex ||= {};
          const apex = globalThis.Apex;
          apex.theme = {
              mode: mode()
          };
          apex.chart = Object.assign(apex.chart || {}, {
              background: 'transparent'
          });
          new MutationObserver(() => {
              const next = mode();
              apex.theme = {
                  mode: next
              };
              const instances = apex._chartInstances || [];
              for (const {
                      chart
                  }
                  of instances) {
                  chart.updateOptions({
                      theme: {
                          mode: next
                      }
                  }, false, false);
              }
          }).observe(document.documentElement, {
              attributes: true,
              attributeFilter: ['data-bs-theme'],
          });
      })();
  </script>
  <!--end::Charts follow the colour mode-->

  <!--begin::Color Mode Toggle-->
  <!-- The light/dark/auto switcher ships in adminlte.js as the ColorMode
     module (since 4.1) — no page script needed. Only the no-flash snippet
     in <head> stays inline, because it must run before first paint. -->
  <!--end::Color Mode Toggle-->

  <!-- OPTIONAL SCRIPTS -->

  <!-- sortablejs -->
  <script src="https://cdn.jsdelivr.net/npm/sortablejs@1.15.0/Sortable.min.js" crossorigin="anonymous"></script>
  <!-- sortablejs -->
  <script>
      new Sortable(document.querySelector('.connectedSortable'), {
          group: 'shared',
          handle: '.card-header',
      });

      const cardHeaders = document.querySelectorAll('.connectedSortable .card-header');
      cardHeaders.forEach((cardHeader) => {
          cardHeader.style.cursor = 'move';
      });
  </script>
  <!-- apexcharts -->
  <script src="https://cdn.jsdelivr.net/npm/apexcharts@3.37.1/dist/apexcharts.min.js"
      integrity="sha256-+vh8GkaU7C9/wbSLIcwq82tQ2wTf44aOHA8HlBMwRI8=" crossorigin="anonymous"></script>
  <!-- ChartJS -->
  <script>
      // NOTICE!! DO NOT USE ANY OF THIS JAVASCRIPT
      // IT'S ALL JUST JUNK FOR DEMO
      // ++++++++++++++++++++++++++++++++++++++++++

      const sales_chart_options = {
          series: [{
                  name: 'Digital Goods',
                  data: [28, 48, 40, 19, 86, 27, 90],
              },
              {
                  name: 'Electronics',
                  data: [65, 59, 80, 81, 56, 55, 40],
              },
          ],
          chart: {
              id: 'revenue-chart',
              height: 300,
              type: 'area',
              toolbar: {
                  show: false,
              },
          },
          legend: {
              show: false,
          },
          colors: ['#0d6efd', '#20c997'],
          dataLabels: {
              enabled: false,
          },
          stroke: {
              curve: 'smooth',
          },
          xaxis: {
              type: 'datetime',
              categories: [
                  '2023-01-01',
                  '2023-02-01',
                  '2023-03-01',
                  '2023-04-01',
                  '2023-05-01',
                  '2023-06-01',
                  '2023-07-01',
              ],
          },
          tooltip: {
              x: {
                  format: 'MMMM yyyy',
              },
          },
      };

      const sales_chart = new ApexCharts(
          document.querySelector('#revenue-chart'),
          sales_chart_options,
      );
      sales_chart.render();
  </script>
  <!-- jsvectormap -->
  <script src="https://cdn.jsdelivr.net/npm/jsvectormap@1.5.3/dist/js/jsvectormap.min.js"
      integrity="sha256-/t1nN2956BT869E6H4V1dnt0X5pAQHPytli+1nTZm2Y=" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/jsvectormap@1.5.3/dist/maps/world.js"
      integrity="sha256-XPpPaZlU8S/HWf7FZLAncLg2SAkP8ScUTII89x9D3lY=" crossorigin="anonymous"></script>
  <!-- jsvectormap -->
  <script>
      // World map by jsVectorMap
      new jsVectorMap({
          selector: '#world-map',
          map: 'world',
      });

      // Sparkline charts
      const option_sparkline1 = {
          series: [{
              data: [1000, 1200, 920, 927, 931, 1027, 819, 930, 1021],
          }, ],
          chart: {
              id: 'sparkline-1',
              type: 'area',
              height: 50,
              sparkline: {
                  enabled: true,
              },
          },
          stroke: {
              curve: 'straight',
          },
          fill: {
              opacity: 0.3,
          },
          yaxis: {
              min: 0,
          },
          colors: ['#DCE6EC'],
      };

      const sparkline1 = new ApexCharts(document.querySelector('#sparkline-1'), option_sparkline1);
      sparkline1.render();

      const option_sparkline2 = {
          series: [{
              data: [515, 519, 520, 522, 652, 810, 370, 627, 319, 630, 921],
          }, ],
          chart: {
              id: 'sparkline-2',
              type: 'area',
              height: 50,
              sparkline: {
                  enabled: true,
              },
          },
          stroke: {
              curve: 'straight',
          },
          fill: {
              opacity: 0.3,
          },
          yaxis: {
              min: 0,
          },
          colors: ['#DCE6EC'],
      };

      const sparkline2 = new ApexCharts(document.querySelector('#sparkline-2'), option_sparkline2);
      sparkline2.render();

      const option_sparkline3 = {
          series: [{
              data: [15, 19, 20, 22, 33, 27, 31, 27, 19, 30, 21],
          }, ],
          chart: {
              id: 'sparkline-3',
              type: 'area',
              height: 50,
              sparkline: {
                  enabled: true,
              },
          },
          stroke: {
              curve: 'straight',
          },
          fill: {
              opacity: 0.3,
          },
          yaxis: {
              min: 0,
          },
          colors: ['#DCE6EC'],
      };

      const sparkline3 = new ApexCharts(document.querySelector('#sparkline-3'), option_sparkline3);
      sparkline3.render();
  </script>
  <!--end::Script-->
