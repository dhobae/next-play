<?php ($eventacara = $eventacara ?? null); ?>

<div class="row">
    <div class="col-md-8">
        <div class="mb-3">
            <label for="judul" class="form-label">Judul</label>
            <input type="text" name="judul" id="judul" class="form-control"
                value="<?php echo e(old('judul', $eventacara?->judul)); ?>" required>
            <?php $__errorArgs = ['judul'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="text-danger"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        

        <div class="mb-3">
            <label for="tanggal" class="form-label">Tanggal</label>
            <input type="date" name="tanggal" id="tanggal" class="form-control"
                value="<?php echo e(old('tanggal', $eventacara?->tanggal)); ?>" required>
            <?php $__errorArgs = ['tanggal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="text-danger"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-3">
            <label for="deskripsi" class="form-label">Deskripsi</label>
            <textarea name="deskripsi" id="deskripsi" class="form-control" rows="6" required><?php echo e(old('deskripsi', $eventacara?->deskripsi)); ?></textarea>
            <?php $__errorArgs = ['deskripsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="text-danger"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="col-md-4">
        <div class="mb-3">
            <label for="gambar" class="form-label">Gambar</label>
            <input type="file" name="gambar" id="gambar" class="form-control"
                accept="image/jpeg,image/png,image/jpg,image/gif,image/svg+xml" <?php echo e($eventacara ? '' : 'required'); ?>>
            <small class="text-muted">Maksimal 2 MB.</small>
            <?php $__errorArgs = ['gambar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="d-block text-danger"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <?php if($eventacara?->gambar): ?>
            <div class="mb-3">
                <div class="mb-2 fw-semibold">Gambar Saat Ini</div>
                <img src="<?php echo e(asset('storage/' . $eventacara->gambar)); ?>" alt="<?php echo e($eventacara->judul); ?>"
                    class="img-fluid rounded" style="max-height: 220px; object-fit: cover;">
            </div>
        <?php endif; ?>

        <div id="preview-container" class="d-none">
            <div class="mb-2 fw-semibold">Preview Gambar Baru</div>
            <img id="preview-gambar" src="" alt="Preview gambar baru" class="img-fluid rounded"
                style="max-height: 220px; object-fit: cover;">
        </div>
    </div>
</div>

<script>
    document.getElementById('gambar').addEventListener('change', function(event) {
        const container = document.getElementById('preview-container');
        const preview = document.getElementById('preview-gambar');
        const file = event.target.files[0];

        if (!file) {
            return;
        }

        preview.src = URL.createObjectURL(file);
        container.classList.remove('d-none');
    });
</script>
<?php /**PATH E:\laragon\www\next-premiere\resources\views\admin\eventacara\partials\form.blade.php ENDPATH**/ ?>