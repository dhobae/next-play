<button type="button" class="btn btn-warning btn-sm edit-riwayat-button" title="Edit" data-bs-toggle="modal"
    data-bs-target="#riwayatModal" data-update-url="<?php echo e(route('admin.atlet-riwayat.update', [$atlet, $riwayat])); ?>"
    data-nama-turnamen="<?php echo e($riwayat->nama_turnamen); ?>"
    data-tanggal-turnamen="<?php echo e($riwayat->tanggal_turnamen?->format('Y-m-d')); ?>"
    data-hasil-turnamen="<?php echo e($riwayat->hasil_turnamen); ?>" data-poin-turnamen="<?php echo e($riwayat->poin_turnamen); ?>">
    <i class="bi bi-pencil-square"></i>
</button>
<form action="<?php echo e(route('admin.atlet-riwayat.destroy', [$atlet, $riwayat])); ?>" method="POST"
    class="d-inline delete-riwayat-form">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
    <button type="submit" class="btn btn-danger btn-sm" title="Hapus">
        <i class="bi bi-trash"></i>
    </button>
</form>
<?php /**PATH E:\laragon\www\next-premiere\resources\views\admin\atlet-riwayat\partials\actions.blade.php ENDPATH**/ ?>