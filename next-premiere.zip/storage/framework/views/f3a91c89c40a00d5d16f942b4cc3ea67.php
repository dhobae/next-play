

<?php $__env->startSection('content'); ?>
    <main>
        <section id="beranda" class="hero-section">
            <div id="heroSlider" class="carousel slide" data-bs-ride="carousel">
                <?php if($carousels->isNotEmpty()): ?>
                    <div class="carousel-indicators">
                        <?php $__currentLoopData = $carousels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carousel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <button type="button" data-bs-target="#heroSlider" data-bs-slide-to="<?php echo e($loop->index); ?>"
                                class="<?php echo e($loop->first ? 'active' : ''); ?>"
                                aria-label="Slide <?php echo e($loop->iteration); ?>"></button>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
                <div class="carousel-inner">
                    <?php $__empty_1 = true; $__currentLoopData = $carousels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carousel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="carousel-item <?php echo e($loop->first ? 'active' : ''); ?>">
                            <div class="hero-slide"
                                style="--hero-image: url('<?php echo e(asset('storage/' . $carousel->gambar)); ?>');">
                                <div class="container">
                                    <div class="hero-copy">
                                        <p class="eyebrow">Beranda</p>
                                        <h1><?php echo e($carousel->judul); ?></h1>
                                        <p class="lead"><?php echo e($carousel->subjudul); ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="carousel-item active">
                            <div class="hero-slide">
                                <div class="container">
                                    <div class="hero-copy">
                                        <p class="eyebrow">KOMUNITAS UNTUK PERUBAHAN</p>
                                        <h1>Bergerak Bersama,<br /><span>Berdampak Nyata.</span></h1>
                                        <p class="lead">Kami percaya perubahan besar lahir dari langkah kecil yang
                                            dilakukan bersama.</p>

                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#heroSlider" data-bs-slide="prev">
                    <span class="carousel-control-icon"><i class="bi bi-arrow-left"></i></span><span
                        class="visually-hidden">Sebelumnya</span></button><button class="carousel-control-next"
                    type="button" data-bs-target="#heroSlider" data-bs-slide="next">
                    <span class="carousel-control-icon"><i class="bi bi-arrow-right"></i></span><span
                        class="visually-hidden">Berikutnya</span>
                </button>
            </div>
        </section>

        <section id="tentang" class="section-padding">
            <div class="container">
                <div class="row align-items-center g-5">

                    <div class="col-lg-6">
                        <div class="image-placeholder about-image">
                            <i class="bi bi-image"></i><span>Placeholder foto kegiatan</span>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        
                        <h2>
                            Tentang Komunitas<br /><span>Kami.</span>
                        </h2>
                        <p class="text-muted mt-4" style="text-align: justify;">
                            Olahraga padel merupakan cabang olahraga raket yang semakin berkembang pesat di dunia, termasuk
                            di Indonesia. Padel dimainkan secara berpasangan di lapangan berdinding, mengombinasikan unsur
                            permainan tenis dan squash, sehingga menghadirkan dinamika permainan yang cepat, menarik, dan
                            mudah dipelajari oleh berbagai kalangan. Keunikan padel terletak pada penggunaan dinding sebagai
                            bagian dari permainan, yang menuntut strategi, ketepatan, serta kerja sama tim yang baik. Selain
                            itu, padel dikenal sebagai olahraga yang inklusif karena dapat dimainkan oleh berbagai usia,
                            mulai dari pemula hingga atlet profesional.
                        </p>
                        <p class="text-muted" style="text-align: justify;">
                            Di Indonesia, khususnya di Kalimantan Selatan, perkembangan olahraga padel menunjukkan tren yang
                            positif dengan semakin bertambahnya venue, komunitas, dan minat masyarakat. Hal ini menjadi
                            peluang besar dalam pembinaan dan pengembangan atlet, terutama pada kelompok usia dini dan
                            remaja. Dengan dukungan organisasi, pelatih, serta kolaborasi antar komunitas, padel tidak hanya
                            menjadi sarana rekreasi, tetapi juga berpotensi melahirkan atlet-atlet berprestasi yang mampu
                            bersaing di tingkat nasional maupun internasional.
                        </p>
                        
                    </div>
                </div>
                
            </div>
        </section>

        <section id="pengurus" class="section-padding section-dark">
            <div class="container">
                <div class="section-heading d-flex justify-content-between align-items-end mb-5">
                    <div>
                        <p class="eyebrow">ORANG-ORANG DI BALIK GERAKAN</p>
                        <h2 class="text-white">
                            Struktur <span>Pengurus.</span>
                        </h2>
                    </div>
                    <p class="heading-note">
                        Bertemu dengan tim yang mendedikasikan waktu,
                        energi, dan hati untuk Karya Bersama.
                    </p>
                </div>
                <div class="row g-4">
                    <div class="col-md-6 col-lg-3">
                        <article class="person-card">
                            <div class="image-placeholder person-image">
                                <i class="bi bi-person"></i>
                            </div>
                            <div class="person-info">
                                <h3>Ahmad Pratama</h3>
                                <p>Ketua Umum</p>
                                <span>01</span>
                            </div>
                        </article>
                    </div>
                    <div class="col-md-6 col-lg-3">
                        <article class="person-card">
                            <div class="image-placeholder person-image">
                                <i class="bi bi-person"></i>
                            </div>
                            <div class="person-info">
                                <h3>Siti Rahma</h3>
                                <p>Sekretaris</p>
                                <span>02</span>
                            </div>
                        </article>
                    </div>
                    <div class="col-md-6 col-lg-3">
                        <article class="person-card">
                            <div class="image-placeholder person-image">
                                <i class="bi bi-person"></i>
                            </div>
                            <div class="person-info">
                                <h3>Bagas Wicaksono</h3>
                                <p>Bendahara</p>
                                <span>03</span>
                            </div>
                        </article>
                    </div>
                    <div class="col-md-6 col-lg-3">
                        <article class="person-card">
                            <div class="image-placeholder person-image">
                                <i class="bi bi-person"></i>
                            </div>
                            <div class="person-info">
                                <h3>Nadia Lestari</h3>
                                <p>Koordinator Program</p>
                                <span>04</span>
                            </div>
                        </article>
                    </div>
                </div>
            </div>
        </section>

        <section id="event" class="section-padding">
            <div class="container">
                <div class="section-heading d-flex justify-content-between align-items-end mb-5">
                    <div>
                        <p class="eyebrow">EVENT TERKINI</p>
                        <h2>Event <span>Terbaru.</span></h2>
                    </div>
                    <a href="<?php echo e(route('events')); ?>" class="link-green">Lihat semua event <i class="bi bi-arrow-right"></i></a>
                </div>
                <div class="row g-4">
                    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4">
                            <article class="news-card">
                                <div class="image-placeholder news-image">
                                    <?php if($event->gambar): ?>
                                        <img src="<?php echo e(asset('storage/' . $event->gambar)); ?>" alt="<?php echo e($event->judul); ?>">
                                    <?php else: ?>
                                        <i class="bi bi-image"></i>
                                    <?php endif; ?>
                                </div>
                                <div class="news-body">
                                    <small><?php echo e(\Carbon\Carbon::parse($event->tanggal)->translatedFormat('d F Y')); ?> ·
                                        EVENT</small>
                                    <h3><?php echo e($event->judul); ?></h3>
                                    <a href="<?php echo e(route('events.show', $event)); ?>" aria-label="Baca event">Baca selengkapnya
                                        <i class="bi bi-arrow-up-right"></i></a>
                                </div>
                            </article>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php for($placeholderIndex = $events->count(); $placeholderIndex < 3; $placeholderIndex++): ?>
                        <div class="col-lg-4">
                            <article class="news-card">
                                <div class="image-placeholder news-image">
                                    <i class="bi bi-calendar-plus"></i>
                                    <span>Event berikutnya akan hadir</span>
                                </div>
                                <div class="news-body">
                                    <small>SEGERA HADIR</small>
                                    <h3>Event baru akan ditambahkan</h3>
                                    <p>Informasi kegiatan berikutnya akan tampil di sini.</p>
                                </div>
                            </article>
                        </div>
                    <?php endfor; ?>
                </div>
            </div>
        </section>

        <section class="sponsor-section">
            <div class="container text-center">
                <p class="eyebrow">DIDUKUNG OLEH</p>
                <h2 class="mb-5">Sponsor & Kolaborator.</h2>
                <div class="splide sponsor-splide" aria-label="Sponsor dan kolaborator">
                    <div class="splide__track">
                        <ul class="splide__list">
                            <?php $__empty_1 = true; $__currentLoopData = $sponsors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sponsor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <li class="splide__slide sponsor-slide">
                                    <?php if($sponsor->gambar): ?>
                                        <img src="<?php echo e(asset('storage/' . $sponsor->gambar)); ?>"
                                            alt="<?php echo e($sponsor->nama_sponsor); ?>" class="img-fluid">
                                    <?php else: ?>
                                        <span><?php echo e($sponsor->nama_sponsor); ?></span>
                                    <?php endif; ?>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <li class="splide__slide sponsor-slide text-muted">Belum ada sponsor.</li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </div>
        </section>

        
    </main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        const sponsorSplide = document.querySelector(".sponsor-splide");
        if (sponsorSplide) {
            const sponsorCount = sponsorSplide.querySelectorAll(".splide__slide").length;

            new Splide(sponsorSplide, {
                perPage: 6,
                gap: "28px",
                type: sponsorCount > 1 ? "loop" : "slide",
                arrows: false,
                pagination: false,
                drag: "free",
                autoScroll: {
                    speed: 0.2,
                    pauseOnHover: true,
                    pauseOnFocus: true,
                },
                breakpoints: {
                    991: {
                        perPage: 3,
                        gap: "20px"
                    },
                    575: {
                        perPage: 2,
                        gap: "14px"
                    },
                },
            }).mount(window.splide.Extensions);
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\next-premiere\resources\views/user/beranda/index.blade.php ENDPATH**/ ?>