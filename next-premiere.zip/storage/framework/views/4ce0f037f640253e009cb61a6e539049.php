  <footer class="site-footer">
      <div class="container">
          <div class="row g-5">
              <div class="col-lg-5">
                  <a class="navbar-brand d-flex align-items-center gap-2" href="/">
                      <span class="brand-mark">
                          <img class="img-fluid" src="<?php echo e(asset('assets/nextpremiere/logo.png')); ?>" alt="LOGO" />
                      </span>
                      <span>NEXT<span> PREMIERE</span></span>
                  </a>
                  <p class="footer-copy">
                      Bergabunglah dengan komunitas padel terbesar di Indonesia. Mainkan, belajar, dan berkembang
                      bersama kami.
                  </p>
              </div>
              <div class="col-6 col-lg-2">
                  <h4>Jelajahi</h4>
                  <a href="<?php echo e(route('beranda')); ?>">Beranda</a><a href="<?php echo e(route('tentangkami')); ?>">Tentang Kami</a><a
                      href="<?php echo e(route('events')); ?>">Event</a><a href="<?php echo e(route('atlets')); ?>">Peringkat</a>
              </div>
              <div class="col-6 col-lg-2">
                  <h4>Terhubung</h4>
                  <a href="#kontak">Instagram</a><a href="#kontak">Facebook</a><a href="#kontak">Tiktok</a><a
                      href="#kontak">Youtube</a>
              </div>
              <div class="col-lg-3">
                  <h4>Kontak</h4>
                  <p>
                      halo@karyabersama.id<br />+62 812 3456 7890<br />Kalimantan Selatan,
                      Indonesia
                  </p>
              </div>
          </div>
          <div class="footer-bottom mt-5">
              <span id="copyright"></span>

              <div>
                  <span>Developed with</span>
                  <i class="fa-solid fa-heart" aria-hidden="true"></i>
                  <span>By Next Premiere</span>
              </div>
          </div>
      </div>
  </footer>
<?php /**PATH E:\laragon\www\next-premiere\resources\views\user\layouts\partials\footer.blade.php ENDPATH**/ ?>