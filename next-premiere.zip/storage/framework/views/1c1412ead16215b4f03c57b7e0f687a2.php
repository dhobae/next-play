<?php ($atlet = $atlet ?? null); ?>
<?php ($jenisKelamin = old('jenis_kelamin', $atlet?->jenis_kelamin)); ?>

<div class="row">
    <div class="col-md-8">
        <div class="row">
            <div class="col-md-6 mb-3">
                <label for="nama_atlet" class="form-label">Nama Atlet</label>
                <input type="text" name="nama_atlet" id="nama_atlet" class="form-control"
                    value="<?php echo e(old('nama_atlet', $atlet?->nama_atlet)); ?>" required>
                <?php $__errorArgs = ['nama_atlet'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-md-6 mb-3">
                <label for="level" class="form-label">Level</label>
                <select name="level" id="level" class="form-select" required>
                    <option value="">Pilih level</option>
                    <?php $__currentLoopData = ['Bronze', 'Silver', 'Elektrum', 'Beginner']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($level); ?>" <?php if(old('level', $atlet?->level) === $level): echo 'selected'; endif; ?>>
                            <?php echo e($level); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['level'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-md-6 mb-3">
                <label for="jenis_kelamin" class="form-label">Jenis Kelamin</label>
                <select name="jenis_kelamin" id="jenis_kelamin" class="form-select" required>
                    <option value="">Pilih jenis kelamin</option>
                    <option value="0" <?php if((string) $jenisKelamin === '0'): echo 'selected'; endif; ?>>Laki-laki</option>
                    <option value="1" <?php if((string) $jenisKelamin === '1'): echo 'selected'; endif; ?>>Perempuan</option>
                </select>
                <?php $__errorArgs = ['jenis_kelamin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-md-6 mb-3">
                <label for="klub_asosiasi" class="form-label">Klub/Asosiasi</label>
                <input type="text" name="klub_asosiasi" id="klub_asosiasi" class="form-control"
                    value="<?php echo e(old('klub_asosiasi', $atlet?->klub_asosiasi)); ?>" required>
                <?php $__errorArgs = ['klub_asosiasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-md-6 mb-3">
                <label for="tempat_lahir" class="form-label">Tempat Lahir</label>
                <input type="text" name="tempat_lahir" id="tempat_lahir" class="form-control"
                    value="<?php echo e(old('tempat_lahir', $atlet?->tempat_lahir)); ?>" required>
                <?php $__errorArgs = ['tempat_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-md-6 mb-3">
                <label for="tanggal_lahir" class="form-label">Tanggal Lahir</label>
                <input type="date" name="tanggal_lahir" id="tanggal_lahir" class="form-control"
                    value="<?php echo e(old('tanggal_lahir', $atlet?->tanggal_lahir?->format('Y-m-d'))); ?>" required>
                <?php $__errorArgs = ['tanggal_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-md-6 mb-3">
                <label for="kebangsaan" class="form-label">Kebangsaan</label>
                <input type="text" name="kebangsaan" id="kebangsaan" class="form-control"
                    value="<?php echo e(old('kebangsaan', $atlet?->kebangsaan)); ?>" required>
                <?php $__errorArgs = ['kebangsaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

    </div>

    <div class="col-md-4">
        <div class="mb-3">
            <label for="foto_atlet" class="form-label">Foto Atlet</label>
            <input type="file" name="foto_atlet" id="foto_atlet" class="form-control"
                accept="image/jpeg,image/png,image/jpg,image/gif,image/svg+xml" <?php echo e($atlet ? '' : 'required'); ?>>
            <small class="text-muted">Maksimal 2 MB.</small>
            <?php $__errorArgs = ['foto_atlet'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="d-block text-danger"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <?php if($atlet?->foto_atlet): ?>
            <div class="mb-3">
                <div class="mb-2 fw-semibold">Foto Saat Ini</div>
                <img src="<?php echo e(asset('storage/' . $atlet->foto_atlet)); ?>" alt="<?php echo e($atlet->nama_atlet); ?>"
                    class="img-fluid rounded" style="max-height: 220px; object-fit: cover;">
            </div>
        <?php endif; ?>

        <div id="preview-container" class="d-none">
            <div class="mb-2 fw-semibold">Preview Foto Baru</div>
            <img id="preview-foto-atlet" src="" alt="Preview foto atlet baru" class="img-fluid rounded"
                style="max-height: 220px; object-fit: cover;">
        </div>
    </div>
</div>

<script>
    document.getElementById('foto_atlet').addEventListener('change', function(event) {
        const container = document.getElementById('preview-container');
        const preview = document.getElementById('preview-foto-atlet');
        const file = event.target.files[0];

        if (!file) {
            return;
        }

        preview.src = URL.createObjectURL(file);
        container.classList.remove('d-none');
    });
</script>
<?php /**PATH E:\laragon\www\next-premiere\resources\views\admin\atlet\partials\form.blade.php ENDPATH**/ ?>