<div class="d-flex justify-content-center align-items-center gap-1">
    <a href="<?php echo e(route('admin.eventacara.edit', $event)); ?>" class="btn btn-warning btn-sm pb-0" title="Edit">
        <i class="bi bi-pencil-square"></i>
    </a>

    <form action="<?php echo e(route('admin.eventacara.destroy', $event)); ?>" method="POST" class="d-inline delete-form">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button type="submit" class="btn btn-danger btn-sm pb-0" title="Hapus">
            <i class="bi bi-trash"></i>
        </button>
    </form>

</div>
<?php /**PATH E:\laragon\www\next-premiere\resources\views\admin\eventacara\partials\actions.blade.php ENDPATH**/ ?>