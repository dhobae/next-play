<!doctype html>
<html lang="id">

<?php echo $__env->make('user.layouts.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>

    <?php echo $__env->make('user.layouts.partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main class="site-main">
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <?php echo $__env->make('user.layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script>
        const siteNav = document.querySelector('.site-nav');

        if (siteNav) {
            const updateSiteNavHeight = () => {
                document.documentElement.style.setProperty('--site-nav-height', `${siteNav.offsetHeight}px`);
            };

            updateSiteNavHeight();
            new ResizeObserver(updateSiteNavHeight).observe(siteNav);
        }
    </script>
    <script>
        document.getElementById('copyright').textContent =
            `© ${new Date().getFullYear()} Next Premiere. All rights reserved.`;
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@splidejs/splide@4.1.4/dist/js/splide.min.js"></script>
    <script
        src="https://cdn.jsdelivr.net/npm/@splidejs/splide-extension-auto-scroll@0.5.3/dist/js/splide-extension-auto-scroll.min.js">
    </script>
    <script src='<?php echo e(asset('/costum/script.js')); ?>'></script>
    <?php echo $__env->yieldContent('scripts'); ?>
</body>

</html>
<?php /**PATH E:\laragon\www\next-premiere\resources\views\user\layouts\app.blade.php ENDPATH**/ ?>