

<?php $__env->startSection('content'); ?>
    <div class="col-12">
        <div class="card shadow-sm">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h3 class="card-title mb-0">Sponsor Beranda</h3>
                <button type="button" class="btn btn-primary btn-sm ms-auto" data-bs-toggle="modal"
                    data-bs-target="#sponsorModal" data-mode="create">
                    <i class="bi bi-plus-circle me-1"></i> Tambah Sponsor
                </button>
            </div>
            <div class="card-body">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul class="mb-0">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <div class="table-responsive">
                    <table class="table table-bordered table-striped align-middle">
                        <thead>
                            <tr>
                                <th style="width: 5%">#</th>
                                <th style="width: 25%">Gambar</th>
                                <th style="width: 45%">Nama Sponsor</th>
                                <th style="width: 15%" class="text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $sponsors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sponsor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td>
                                        <?php if($sponsor->gambar): ?>
                                            <img src="<?php echo e(asset('storage/' . $sponsor->gambar)); ?>"
                                                alt="<?php echo e($sponsor->nama_sponsor); ?>" class="img-fluid rounded"
                                                style="max-height: 90px; object-fit: cover;">
                                        <?php else: ?>
                                            <span class="text-muted">Tidak ada gambar</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($sponsor->nama_sponsor); ?></td>
                                    <td class="text-center">
                                        <button type="button" class="btn btn-warning btn-sm me-1 btn-edit-sponsor"
                                            data-id="<?php echo e($sponsor->id); ?>" data-nama_sponsor="<?php echo e($sponsor->nama_sponsor); ?>"
                                            data-gambar="<?php echo e($sponsor->gambar); ?>" data-bs-toggle="modal"
                                            data-bs-target="#sponsorModal" data-mode="edit">
                                            <i class="bi bi-pencil-square"></i>
                                        </button>

                                        <form action="<?php echo e(route('admin.sponsor.destroy', $sponsor->id)); ?>" method="POST"
                                            class="d-inline delete-form">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger btn-sm">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="4" class="text-center text-muted py-4">Belum ada data sponsor.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="sponsorModal" tabindex="-1" aria-labelledby="sponsorModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <form id="sponsorForm" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="_method" id="sponsorMethod" value="POST">
                    <div class="modal-header">
                        <h5 class="modal-title" id="sponsorModalLabel">Tambah Sponsor</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="nama_sponsor" class="form-label">Nama Sponsor</label>
                            <input type="text" name="nama_sponsor" id="nama_sponsor" class="form-control"
                                value="<?php echo e(old('nama_sponsor')); ?>">
                            <?php $__errorArgs = ['nama_sponsor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="mb-3">
                            <label for="sponsor_gambar" class="form-label">Gambar</label>
                            <input type="file" name="gambar" id="sponsor_gambar" class="form-control" accept="image/*">
                            <?php $__errorArgs = ['gambar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <div class="mt-2 d-flex gap-3 flex-wrap">
                                <div id="previewOldWrapper" style="display: none;">
                                    <p class="mb-1 small text-muted">Gambar saat ini:</p>
                                    <img id="previewGambarLama" src="" alt="Gambar lama"
                                        class="img-fluid rounded border" style="max-height: 150px; object-fit: cover;">
                                </div>
                                <div id="previewNewWrapper" style="display: none;">
                                    <p id="previewNewLabel" class="mb-1 small text-muted">Preview gambar:</p>
                                    <img id="previewGambarBaru" src="" alt="Preview gambar"
                                        class="img-fluid rounded border" style="max-height: 150px; object-fit: cover;">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary btn-sm">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            const sponsorModal = $('#sponsorModal');
            const sponsorForm = $('#sponsorForm');
            const sponsorMethod = $('#sponsorMethod');
            const sponsorModalLabel = $('#sponsorModalLabel');

            let currentMode = 'create';

            $('button[data-bs-target="#sponsorModal"]').on('click', function() {
                const mode = $(this).data('mode');

                if (mode === 'create') {
                    currentMode = 'create';
                    sponsorForm.attr('action', '<?php echo e(route('admin.sponsor.store')); ?>');
                    sponsorMethod.val('POST');
                    sponsorModalLabel.text('Tambah sponsor');
                    sponsorForm[0].reset();
                    $('#nama_sponsor').val('');
                    $('#sponsor_gambar').val('');

                    $('#previewGambarLama').attr('src', '');
                    $('#previewOldWrapper').hide();
                    $('#previewGambarBaru').attr('src', '');
                    $('#previewNewWrapper').hide();
                }
            });

            $('.btn-edit-sponsor').on('click', function() {
                currentMode = 'edit';
                const id = $(this).data('id');
                const namaSponsor = $(this).data('nama_sponsor');
                const gambar = $(this).data('gambar');

                sponsorForm.attr('action', '<?php echo e(url('admin/sponsor')); ?>/' + id);
                sponsorMethod.val('PUT');
                sponsorModalLabel.text('Edit sponsor');

                $('#nama_sponsor').val(namaSponsor);
                $('#sponsor_gambar').val('');

                $('#previewGambarBaru').attr('src', '');
                $('#previewNewWrapper').hide();

                if (gambar) {
                    $('#previewGambarLama').attr('src', '<?php echo e(asset('storage')); ?>/' + gambar);
                    $('#previewOldWrapper').show();
                } else {
                    $('#previewGambarLama').attr('src', '');
                    $('#previewOldWrapper').hide();
                }
            });

            // Preview saat user pilih file baru
            $('#sponsor_gambar').on('change', function() {
                const file = this.files[0];
                if (file) {
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        $('#previewGambarBaru').attr('src', e.target.result);
                        $('#previewNewLabel').text(currentMode === 'edit' ? 'Preview gambar baru:' :
                            'Preview gambar:');
                        $('#previewNewWrapper').show();
                    };
                    reader.readAsDataURL(file);
                } else {
                    $('#previewGambarBaru').attr('src', '');
                    $('#previewNewWrapper').hide();
                }
            });

            $('.delete-form').on('submit', function(e) {
                e.preventDefault();

                Swal.fire({
                    title: 'Yakin ingin menghapus?',
                    text: 'Data sponsor ini akan dihapus permanen.',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#d33',
                    cancelButtonColor: '#6c757d',
                    confirmButtonText: 'Ya, hapus!',
                    cancelButtonText: 'Batal'
                }).then((result) => {
                    if (result.isConfirmed) {
                        this.submit();
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\next-premiere\resources\views\admin\beranda\sponsor\index.blade.php ENDPATH**/ ?>