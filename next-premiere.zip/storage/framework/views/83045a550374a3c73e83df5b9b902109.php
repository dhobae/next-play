<?php ($riwayat = $riwayat ?? null); ?>

<div class="row">
    <div class="col-md-6 mb-3">
        <label for="nama_turnamen" class="form-label">Nama Turnamen</label>
        <input type="text" name="nama_turnamen" id="nama_turnamen" class="form-control"
            value="<?php echo e(old('nama_turnamen', $riwayat?->nama_turnamen)); ?>" required>
        <?php $__errorArgs = ['nama_turnamen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="text-danger"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="col-md-6 mb-3">
        <label for="tanggal_turnamen" class="form-label">Tanggal Turnamen</label>
        <input type="date" name="tanggal_turnamen" id="tanggal_turnamen" class="form-control"
            value="<?php echo e(old('tanggal_turnamen', $riwayat?->tanggal_turnamen?->format('Y-m-d'))); ?>" required>
        <?php $__errorArgs = ['tanggal_turnamen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="text-danger"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="col-md-6 mb-3">
        <label for="hasil_turnamen" class="form-label">Hasil Turnamen</label>
        <select name="hasil_turnamen" id="hasil_turnamen" class="form-select select2" required>
            <option value="">Pilih hasil turnamen</option>
            <?php $__currentLoopData = ['Champions', 'Runner Up', 'R32', 'R16', 'R8', 'R4', 'Kualifikasi']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hasil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($hasil); ?>" <?php if(old('hasil_turnamen', $riwayat?->hasil_turnamen) === $hasil): echo 'selected'; endif; ?>>
                    <?php echo e($hasil); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php $__errorArgs = ['hasil_turnamen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="text-danger"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="col-md-6 mb-3">
        <label for="poin_turnamen" class="form-label">Poin Turnamen</label>
        <input type="number" name="poin_turnamen" id="poin_turnamen" class="form-control"
            value="<?php echo e(old('poin_turnamen', $riwayat?->poin_turnamen)); ?>" required>
        <?php $__errorArgs = ['poin_turnamen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="text-danger"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>

<script>
    const hasilTurnamenModal = $('#hasil_turnamen').closest('.modal');

    $('#hasil_turnamen').select2({
        theme: 'bootstrap-5',
        placeholder: 'Pilih hasil turnamen',
        width: '100%',
        dropdownParent: hasilTurnamenModal.length ? hasilTurnamenModal : $(document.body)
    });
</script>
<?php /**PATH E:\laragon\www\next-premiere\resources\views\admin\atlet-riwayat\partials\form.blade.php ENDPATH**/ ?>