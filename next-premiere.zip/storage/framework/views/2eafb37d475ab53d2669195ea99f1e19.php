

<?php $__env->startSection('content'); ?>
    <div class="col-12">
        <div class="card shadow-sm">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h3 class="card-title mb-0">Hero Peringkat</h3>
                <?php if($heroes->isEmpty()): ?>
                    <button type="button" class="btn btn-primary btn-sm ms-auto" data-bs-toggle="modal"
                        data-bs-target="#heroModal" data-mode="create"><i class="bi bi-plus-circle me-1"></i> Tambah
                        Hero</button>
                <?php endif; ?>
            </div>
            <div class="card-body">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul class="mb-0">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <div class="table-responsive">
                    <table class="table table-bordered table-striped align-middle">
                        <thead>
                            <tr>
                                <th style="width:5%">#</th>
                                <th style="width:20%">Gambar</th>
                                <th style="width:25%">Judul</th>
                                <th style="width:25%">Subjudul</th>
                                <th style="width:15%" class="text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $heroes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hero): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td>
                                        <?php if($hero->gambar): ?>
                                            <img src="<?php echo e(asset('storage/' . $hero->gambar)); ?>" alt="<?php echo e($hero->judul); ?>"
                                                class="img-fluid rounded"
                                            style="max-height:90px;object-fit:cover;"><?php else: ?><span
                                                class="text-muted">Tidak ada gambar</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($hero->judul); ?></td>
                                    <td><?php echo e($hero->subjudul); ?></td>
                                    <td class="text-center"><button type="button"
                                            class="btn btn-warning btn-sm me-1 btn-edit-hero" data-id="<?php echo e($hero->id); ?>"
                                            data-judul="<?php echo e($hero->judul); ?>" data-subjudul="<?php echo e($hero->subjudul); ?>"
                                            data-gambar="<?php echo e($hero->gambar); ?>" data-bs-toggle="modal"
                                            data-bs-target="#heroModal"><i class="bi bi-pencil-square"></i></button>
                                        <?php if($heroes->count() > 1): ?>
                                            <form action="<?php echo e(route('admin.heroatlet.destroy', $hero->id)); ?>" method="POST"
                                                class="d-inline delete-form"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button type="submit"
                                                    class="btn btn-danger btn-sm"><i class="bi bi-trash"></i></button>
                                            </form>
                                        <?php endif; ?>
                                    </td>
                            </tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr>
                                    <td colspan="5" class="text-center text-muted py-4">Belum ada data hero.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="heroModal" tabindex="-1" aria-labelledby="heroModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <form id="heroForm" method="POST" enctype="multipart/form-data"><?php echo csrf_field(); ?><input type="hidden" name="_method"
                        id="heroMethod" value="POST">
                    <div class="modal-header">
                        <h5 class="modal-title" id="heroModalLabel">Tambah Hero</h5><button type="button" class="btn-close"
                            data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3"><label for="judul" class="form-label">Judul</label><input type="text"
                                name="judul" id="judul" class="form-control" value="<?php echo e(old('judul')); ?>">
                            <?php $__errorArgs = ['judul'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3"><label for="subjudul" class="form-label">Subjudul</label>
                            <textarea name="subjudul" id="subjudul" class="form-control" rows="4"><?php echo e(old('subjudul')); ?></textarea>
                            <?php $__errorArgs = ['subjudul'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3"><label for="gambar" class="form-label">Gambar</label><input type="file"
                                name="gambar" id="gambar" class="form-control" accept="image/*">
                            <?php $__errorArgs = ['gambar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <div class="mt-2 d-flex gap-3 flex-wrap">
                                <div id="previewOldWrapper" style="display:none">
                                    <p class="mb-1 small text-muted">Gambar saat ini:</p><img id="previewGambarLama"
                                        src="" alt="Gambar lama" class="img-fluid rounded border"
                                        style="max-height:150px;object-fit:cover;">
                                </div>
                                <div id="previewNewWrapper" style="display:none">
                                    <p id="previewNewLabel" class="mb-1 small text-muted">Preview gambar:</p><img
                                        id="previewGambarBaru" src="" alt="Preview gambar"
                                        class="img-fluid rounded border" style="max-height:150px;object-fit:cover;">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer"><button type="button" class="btn btn-secondary btn-sm"
                            data-bs-dismiss="modal">Batal</button><button type="submit"
                            class="btn btn-primary btn-sm">Simpan</button></div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            const form = $('#heroForm'),
                method = $('#heroMethod');
            let mode = 'create';
            $('button[data-bs-target="#heroModal"]').on('click', function() {
                if ($(this).data('mode') !== 'create') return;
                mode = 'create';
                form.attr('action', '<?php echo e(route('admin.heroatlet.store')); ?>');
                method.val('POST');
                $('#heroModalLabel').text('Tambah Hero');
                form[0].reset();
                $('#previewOldWrapper,#previewNewWrapper').hide();
            });
            $('.btn-edit-hero').on('click', function() {
                const button = $(this);
                mode = 'edit';
                form.attr('action', '<?php echo e(url('admin/heroatlet')); ?>/' + button.data('id'));
                method.val('PUT');
                $('#heroModalLabel').text('Edit Hero');
                $('#judul').val(button.data('judul'));
                $('#subjudul').val(button.data('subjudul'));
                $('#gambar').val('');
                $('#previewNewWrapper').hide();
                if (button.data('gambar')) {
                    $('#previewGambarLama').attr('src', '<?php echo e(asset('storage')); ?>/' + button.data('gambar'));
                    $('#previewOldWrapper').show();
                } else $('#previewOldWrapper').hide();
            });
            $('#gambar').on('change', function() {
                const file = this.files[0];
                if (!file) return $('#previewNewWrapper').hide();
                const reader = new FileReader();
                reader.onload = function(event) {
                    $('#previewGambarBaru').attr('src', event.target.result);
                    $('#previewNewLabel').text(mode === 'edit' ? 'Preview gambar baru:' :
                        'Preview gambar:');
                    $('#previewNewWrapper').show();
                };
                reader.readAsDataURL(file);
            });
            $('.delete-form').on('submit', function(event) {
                event.preventDefault();
                Swal.fire({
                    title: 'Yakin ingin menghapus?',
                    text: 'Data hero ini akan dihapus permanen.',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#d33',
                    cancelButtonColor: '#6c757d',
                    confirmButtonText: 'Ya, hapus!',
                    cancelButtonText: 'Batal'
                }).then((result) => {
                    if (result.isConfirmed) this.submit();
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\next-premiere\resources\views\admin\atlet\hero\index.blade.php ENDPATH**/ ?>