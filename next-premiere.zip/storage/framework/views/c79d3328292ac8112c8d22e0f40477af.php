<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title>Kode Verifikasi Registrasi</title>
</head>

<body>
    <p>Gunakan kode berikut untuk menyelesaikan registrasi akun Anda:</p>
    <h2><?php echo e($code); ?></h2>
    <p>Kode ini berlaku selama 10 menit. Jangan bagikan kode ini kepada siapa pun.</p>
</body>

</html>
<?php /**PATH E:\laragon\www\next-premiere\resources\views\emails\registration-otp.blade.php ENDPATH**/ ?>