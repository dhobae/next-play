

<?php $__env->startSection('content'); ?>
    <section class="section-padding">
        <div class="container mb-3">
            <nav aria-label="Breadcrumb">
                <ol class="breadcrumb detail-breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('beranda')); ?>">Beranda</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('events')); ?>">Event</a></li>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo e($event->judul); ?></li>
                </ol>
            </nav>
        </div>
        <div class="container">
            <div class="row g-5">
                <div class="col-lg-8">
                    <div class="image-placeholder detail-image">
                        <?php if($event->gambar): ?>
                            <img src="<?php echo e(asset('storage/' . $event->gambar)); ?>" alt="<?php echo e($event->judul); ?>">
                        <?php else: ?>
                            <span>Belum ada gambar event</span><i class="bi bi-image"></i>
                        <?php endif; ?>
                    </div>
                    <div class="detail-copy mt-5">
                        
                        <p class="event-date detail-date">
                            <?php echo e(\Carbon\Carbon::parse($event->tanggal)->locale('id')->translatedFormat('l, d F Y')); ?>

                        </p>
                        <h2><?php echo e($event->judul); ?></h2>
                        <p><?php echo nl2br(e($event->deskripsi)); ?></p>
                        <?php
                            $shareUrl = url()->current();
                            $shareText = $event->judul;
                        ?>
                        <div class="detail-share">
                            <p class="eyebrow">BAGIKAN ARTIKEL</p>
                            <div class="share-links" aria-label="Bagikan event">
                                <a class="share-link share-facebook"
                                    href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(rawurlencode($shareUrl)); ?>"
                                    target="_blank" rel="noopener noreferrer" aria-label="Bagikan ke Facebook"
                                    title="Bagikan ke Facebook"><i class="bi bi-facebook"></i></a>
                                <a class="share-link share-whatsapp"
                                    href="https://wa.me/?text=<?php echo e(rawurlencode($shareText . ' ' . $shareUrl)); ?>"
                                    target="_blank" rel="noopener noreferrer" aria-label="Bagikan ke WhatsApp"
                                    title="Bagikan ke WhatsApp"><i class="bi bi-whatsapp"></i></a>
                                <a class="share-link share-twitter"
                                    href="https://twitter.com/intent/tweet?url=<?php echo e(rawurlencode($shareUrl)); ?>&text=<?php echo e(rawurlencode($shareText)); ?>"
                                    target="_blank" rel="noopener noreferrer" aria-label="Bagikan ke Twitter"
                                    title="Bagikan ke Twitter"><i class="bi bi-twitter-x"></i></a>
                                <button class="share-link share-copy" type="button" data-share-url="<?php echo e($shareUrl); ?>"
                                    aria-label="Salin tautan event" title="Salin tautan event"><i
                                        class="bi bi-link-45deg"></i></button>
                            </div>
                            <span class="share-copy-status" role="status" aria-live="polite"></span>
                        </div>
                    </div>
                </div>
                <aside class="col-lg-4">
                    <div class="event-sidebar">
                        <div class="related-events-sidebar">
                            <p class="eyebrow">JANGAN LEWATKAN</p>
                            <h2>Event <span>lainnya.</span></h2>
                            <div class="related-events-list">
                                <?php $__currentLoopData = $relatedEvents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relatedEvent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <article class="related-event-card">
                                        <a class="related-event-image" href="<?php echo e(route('events.show', $relatedEvent)); ?>">
                                            <?php if($relatedEvent->gambar): ?>
                                                <img src="<?php echo e(asset('storage/' . $relatedEvent->gambar)); ?>"
                                                    alt="<?php echo e($relatedEvent->judul); ?>">
                                            <?php else: ?>
                                                <span><i class="bi bi-image"></i></span>
                                            <?php endif; ?>
                                        </a>
                                        <p class="event-date">
                                            <?php echo e(\Carbon\Carbon::parse($relatedEvent->tanggal)->locale('id')->translatedFormat('d F Y')); ?>

                                        </p>
                                        <h3><?php echo e($relatedEvent->judul); ?></h3>
                                        <a class="link-green" href="<?php echo e(route('events.show', $relatedEvent)); ?>">
                                            Lihat selengkapnya <i class="bi bi-arrow-right"></i>
                                        </a>
                                    </article>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php for($placeholderIndex = $relatedEvents->count(); $placeholderIndex < 3; $placeholderIndex++): ?>
                                    <article class="related-event-card related-event-placeholder">
                                        <div class="related-event-image">
                                            <span><i class="bi bi-calendar-plus"></i></span>
                                        </div>
                                        <p class="event-date">SEGERA HADIR</p>
                                        <h3>Event lainnya akan hadir</h3>
                                        <p class="related-event-placeholder-copy">Informasi event berikutnya akan tampil di
                                            sini.</p>
                                    </article>
                                <?php endfor; ?>
                            </div>
                        </div>
                    </div>
            </div>
            </aside>
        </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        document.querySelectorAll('.share-copy').forEach(function(button) {
            button.addEventListener('click', async function() {
                const url = this.dataset.shareUrl;
                const status = this.closest('.detail-share').querySelector('.share-copy-status');

                try {
                    await navigator.clipboard.writeText(url);
                } catch (error) {
                    const input = document.createElement('textarea');
                    input.value = url;
                    input.setAttribute('readonly', '');
                    input.style.position = 'absolute';
                    input.style.left = '-9999px';
                    document.body.appendChild(input);
                    input.select();
                    document.execCommand('copy');
                    input.remove();
                }

                status.textContent = 'Tautan berhasil disalin.';
                window.setTimeout(function() {
                    status.textContent = '';
                }, 2500);
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\next-premiere\resources\views/user/events/show.blade.php ENDPATH**/ ?>