

<?php $__env->startSection('content'); ?>
    <div class="col-12">
        <div class="card shadow-sm">
            <div class="card-header">
                <h3 class="card-title mb-0">Pilih Atlet</h3>
            </div>
            <div class="card-body">
                <p class="text-muted">Pilih atlet untuk melihat dan mengelola riwayat turnamennya.</p>
                <form action="<?php echo e(route('admin.atlet-riwayat.index')); ?>" method="GET" id="pilih-atlet-form">
                    <div class="row align-items-end">
                        <div class="col-md-8 mb-3 mb-md-0">
                            <label for="atlet_id" class="form-label">Nama Atlet</label>
                            <select id="atlet_id" class="form-select" required>
                                <option value="">Cari nama atlet...</option>
                                <?php $__currentLoopData = $atlets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $atlet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($atlet->id); ?>"><?php echo e($atlet->nama_atlet); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="bi bi-check-circle me-1"></i> Konfirmasi Atlet
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(function() {
            $('#atlet_id').select2({
                theme: 'bootstrap-5',
                placeholder: 'Cari nama atlet...',
                width: '100%'
            });

            $('#pilih-atlet-form').on('submit', function(event) {
                event.preventDefault();
                const atletId = $('#atlet_id').val();

                if (atletId) {
                    window.location.href = '<?php echo e(url('admin/atlet-riwayat/atlet')); ?>/' + atletId;
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\next-premiere\resources\views\admin\atlet-riwayat\index.blade.php ENDPATH**/ ?>