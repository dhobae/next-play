<?php if(session('success')): ?>
    <script>
        $(document).ready(function() {
            Swal.fire({
                icon: 'success',
                title: 'Sukses',
                text: "<?php echo e(session('success')); ?>",
                timer: 1500,
                showConfirmButton: false
            });
        });
    </script>
<?php endif; ?>

<?php /**PATH E:\laragon\www\next-premiere\resources\views\admin\layouts\partials\alert.blade.php ENDPATH**/ ?>