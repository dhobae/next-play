

<?php $__env->startSection('content'); ?>
    <?php
        $levelClass = strtolower($atlet->level);
        $levelIcon = match ($levelClass) {
            'elektrum' => 'fa-solid fa-crown',
            'silver', 'bronze' => 'fa-solid fa-medal',
            'beginner' => 'fa-solid fa-shield-halved',
            default => 'fa-solid fa-shield-halved',
        };
        $initial = strtoupper(substr($atlet->nama_atlet, 0, 1));
        $rankBadgeClass = match ((int) $rank) {
            1 => 'rank-gold',
            2 => 'rank-dark-silver',
            3 => 'rank-bronze',
            default => 'rank-light-silver',
        };
    ?>

    <section class="athlete-detail-hero">
        <div class="container">
            <a class="athlete-back-link" href="<?php echo e(route('atlets')); ?>"><i class="fa-solid fa-arrow-left"></i> Kembali ke
                Peringkat</a>
            <div class="athlete-detail-profile">
                <div class="athlete-detail-avatar-wrap">
                    <div class="athlete-detail-avatar">
                        <?php if($atlet->foto_atlet): ?>
                            <img src="<?php echo e(asset('storage/' . $atlet->foto_atlet)); ?>" alt="<?php echo e($atlet->nama_atlet); ?>">
                        <?php else: ?>
                            <span><?php echo e($initial); ?></span>
                        <?php endif; ?>
                    </div>
                    <span class="athlete-rank-chip <?php echo e($rankBadgeClass); ?>"><i class="fa-solid fa-trophy"></i>
                        #<?php echo e($rank); ?></span>
                </div>
                <div class="athlete-detail-copy">
                    <h1><?php echo e($atlet->nama_atlet); ?> <span class="detail-level level-<?php echo e($levelClass); ?>"><i
                                class="<?php echo e($levelIcon); ?>"></i> (<?php echo e($atlet->level); ?>)</span></h1>
                    <p class="detail-rank-label">Peringkat <?php echo e($rank); ?></p>
                    <div class="athlete-detail-tags">
                        <span><i class="fa-solid fa-flag"></i> <?php echo e($atlet->kebangsaan ?: '-'); ?></span>
                        <span><i class="fa-solid fa-location-dot"></i> <?php echo e($atlet->tempat_lahir ?: '-'); ?></span>
                        <span><i class="fa-solid fa-star"></i> <?php echo e($totalPoin); ?> Poin</span>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="section-padding athlete-detail-section">
        <div class="container">
            <div class="athlete-detail-grid">
                <article class="detail-card">
                    <h2>Informasi Pribadi</h2>
                    <dl class="detail-list">
                        <div>
                            <dt><i class="fa-regular fa-calendar"></i> Tanggal Lahir</dt>
                            <dd><?php echo e($atlet->tanggal_lahir?->translatedFormat('d F Y') ?: '-'); ?></dd>
                        </div>
                        <div>
                            <dt><i class="fa-solid fa-location-dot"></i> Tempat Lahir</dt>
                            <dd><?php echo e($atlet->tempat_lahir ?: '-'); ?></dd>
                        </div>
                        <div>
                            <dt><i class="fa-solid fa-flag"></i> Kebangsaan</dt>
                            <dd><?php echo e($atlet->kebangsaan ?: '-'); ?></dd>
                        </div>
                    </dl>
                </article>
                <article class="detail-card">
                    <h2>Statistik</h2>
                    <div class="stat-list">
                        <div class="stat-item stat-green"><span>Total Poin</span><strong><?php echo e($totalPoin); ?></strong></div>
                        <div class="stat-item stat-grey"><span>Total Turnamen</span><strong><?php echo e($totalTurnamen); ?></strong>
                        </div>
                        <div class="stat-item stat-purple"><span>Peringkat
                                Nasional</span><strong>#<?php echo e($rank); ?></strong></div>
                    </div>
                </article>
            </div>

            <article class="detail-card tournament-card">
                <h2>Riwayat Turnamen</h2>
                <div class="detail-tournament-table-wrap">
                    <table class="detail-tournament-table">
                        <thead>
                            <tr>
                                <th>Turnamen</th>
                                <th>Tanggal</th>
                                <th>Hasil</th>
                                <th>Poin</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $atlet->riwayatTurnamen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $riwayat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($riwayat->nama_turnamen); ?></td>
                                    <td><?php echo e($riwayat->tanggal_turnamen?->translatedFormat('d M Y') ?: '-'); ?></td>
                                    <td><span class="result-badge"><?php echo e($riwayat->hasil_turnamen); ?></span></td>
                                    <td class="detail-points">+<?php echo e($riwayat->poin_turnamen); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="4" class="empty-history">Belum ada riwayat turnamen.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </article>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\next-premiere\resources\views\user\atlets\show.blade.php ENDPATH**/ ?>