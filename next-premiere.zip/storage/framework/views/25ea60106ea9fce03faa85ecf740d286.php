

<?php $__env->startSection('content'); ?>
    <section class="event-hero"
        <?php if($hero?->gambar): ?> style="--event-hero-image: url('<?php echo e(asset('storage/' . $hero->gambar)); ?>');" <?php endif; ?>>
        <div class="container">
            <p class="eyebrow">Event</p>
            <h1><?php echo e($hero?->judul ?? 'JUDUL EVENT'); ?></h1>
            <p><?php echo e($hero?->subjudul ?? ''); ?></p>
        </div>
    </section>

    <section class="section-padding">
        <div class="container">
            <div class="section-heading event-heading">
                <div>
                    <p class="eyebrow">JANGAN LEWATKAN</p>
                    <h2>Event <span>terkini.</span></h2>
                </div>
            </div>

            <!-- Featured event (1 besar) -->
            <?php if($eventAcara->isNotEmpty()): ?>
                <?php ($featuredEvent = $eventAcara->first()); ?>
                <article class="featured-event mb-5">
                    <div class="image-placeholder featured-event-image">
                        <?php if($featuredEvent->gambar): ?>
                            <img src="<?php echo e(asset('storage/' . $featuredEvent->gambar)); ?>" alt="<?php echo e($featuredEvent->judul); ?>">
                        <?php else: ?>
                            <span>Placeholder foto event utama</span><i class="bi bi-image"></i>
                        <?php endif; ?>
                    </div>
                    <div class="featured-event-copy">
                        <div class="event-meta">
                            <span><i class="bi bi-calendar3"></i>
                                <?php echo e(\Carbon\Carbon::parse($featuredEvent->tanggal)->translatedFormat('d F Y')); ?></span>
                        </div>
                        <h3><?php echo e($featuredEvent->judul); ?></h3>
                        <p><?php echo e(Str::limit($featuredEvent->deskripsi, 100, '...')); ?></p>
                        <a class="link-green" href="<?php echo e(route('events.show', $featuredEvent)); ?>">Lihat selengkapnya
                            <i class="bi bi-arrow-right"></i></a>
                    </div>
                </article>
            <?php else: ?>
                <article class="featured-event mb-5">
                    <div class="image-placeholder featured-event-image">
                        <span>Belum ada event terbaru</span><i class="bi bi-calendar-event"></i>
                    </div>
                    <div class="featured-event-copy">
                        <h3>Belum ada event terbaru</h3>
                        <p>Event dan kegiatan terbaru akan tampil di halaman ini.</p>
                    </div>
                </article>
            <?php endif; ?>

            <!-- Splide event lainnya -->
            <?php if($eventAcara->isNotEmpty()): ?>
                <div class="event-splide-wrap">
                    <div class="splide event-splide" aria-label="Event terkini">
                        <div class="splide__track">
                            <ul class="splide__list">
                                <?php $__currentLoopData = $eventAcara->skip(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="splide__slide" id="event-<?php echo e($event->id); ?>">
                                        <article class="event-grid-card">
                                            <div class="image-placeholder event-grid-image">
                                                <?php if($event->gambar): ?>
                                                    <img src="<?php echo e(asset('storage/' . $event->gambar)); ?>"
                                                        alt="<?php echo e($event->judul); ?>">
                                                <?php else: ?>
                                                    <i class="bi bi-image"></i>
                                                <?php endif; ?>
                                            </div>
                                            <span
                                                class="event-date"><?php echo e(\Carbon\Carbon::parse($event->tanggal)->translatedFormat('d F Y')); ?></span>
                                            <h3><?php echo e($event->judul); ?></h3>
                                            <p><?php echo e(Str::limit($event->deskripsi, 100, '...')); ?></p>
                                            <a href="<?php echo e(route('events.show', $event)); ?>">Lihat selengkapnya
                                                <i class="bi bi-arrow-right"></i></a>
                                        </article>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php for($placeholderIndex = $eventAcara->skip(1)->count(); $placeholderIndex < 3; $placeholderIndex++): ?>
                                    <li class="splide__slide">
                                        <article class="event-grid-card event-placeholder-card">
                                            <div class="image-placeholder event-grid-image">
                                                <i class="bi bi-calendar-plus"></i>
                                                <span>Event berikutnya akan hadir</span>
                                            </div>
                                            <span class="event-date">SEGERA HADIR</span>
                                            <h3>Event baru akan ditambahkan</h3>
                                            <p>Informasi kegiatan berikutnya akan tampil di sini.</p>
                                        </article>
                                    </li>
                                <?php endfor; ?>
                            </ul>
                        </div>
                    </div>

                    
                </div>
            <?php endif; ?>
        </div>
    </section>

    <section class="sponsor-section">
        <div class="container text-center">
            <p class="eyebrow">DIDUKUNG OLEH</p>
            <h2 class="mb-5">Sponsor & Kolaborator.</h2>
            <div class="splide sponsor-splide" aria-label="Sponsor dan kolaborator">
                <div class="splide__track">
                    <ul class="splide__list">
                        <?php $__empty_1 = true; $__currentLoopData = $sponsors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sponsor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <li class="splide__slide sponsor-slide">
                                <?php if($sponsor->gambar): ?>
                                    <img src="<?php echo e(asset('storage/' . $sponsor->gambar)); ?>"
                                        alt="<?php echo e($sponsor->nama_sponsor); ?>" class="img-fluid">
                                <?php else: ?>
                                    <span><?php echo e($sponsor->nama_sponsor); ?></span>
                                <?php endif; ?>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <li class="splide__slide sponsor-slide text-muted">Belum ada sponsor.</li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        const eventSplideElement = document.querySelector(".event-splide");
        if (eventSplideElement) {
            const secondaryEventCount = <?php echo e(max($eventAcara->count() - 1, 0)); ?>;
            const eventSlideCount = Math.max(3, secondaryEventCount);

            const eventSplide = new Splide(eventSplideElement, {
                type: secondaryEventCount > 3 ? "loop" : "slide",
                perPage: 3,
                gap: "24px",
                pagination: eventSlideCount > 3,
                autoplay: {
                    delay: 3500,
                    disableOnInteraction: false,
                },
                breakpoints: {
                    991: {
                        perPage: 2,
                        gap: "20px"
                    },
                    575: {
                        perPage: 1,
                        gap: "16px"
                    },
                },
            });
            eventSplide.mount();
        }
    </script>

    <script>
        const sponsorSplide = document.querySelector(".sponsor-splide");
        if (sponsorSplide) {
            const sponsorCount = sponsorSplide.querySelectorAll(".splide__slide").length;

            new Splide(sponsorSplide, {
                perPage: 6,
                gap: "28px",
                type: sponsorCount > 1 ? "loop" : "slide",
                arrows: false,
                pagination: false,
                drag: "free",
                autoScroll: {
                    speed: 0.2,
                    pauseOnHover: true,
                    pauseOnFocus: true,
                },
                breakpoints: {
                    991: {
                        perPage: 3,
                        gap: "20px"
                    },
                    575: {
                        perPage: 2,
                        gap: "14px"
                    },
                },
            }).mount(window.splide.Extensions);
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\next-premiere\resources\views\user\events\index.blade.php ENDPATH**/ ?>