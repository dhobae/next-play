<a href="<?php echo e(route('admin.atlet.show', $atlet)); ?>" class="btn btn-info btn-sm me-1" title="Detail">
    <i class="bi bi-eye"></i>
</a>
<a href="<?php echo e(route('admin.atlet.edit', $atlet)); ?>" class="btn btn-warning btn-sm me-1" title="Edit">
    <i class="bi bi-pencil-square"></i>
</a>

<form action="<?php echo e(route('admin.atlet.destroy', $atlet)); ?>" method="POST" class="d-inline delete-form">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
    <button type="submit" class="btn btn-danger btn-sm" title="Hapus">
        <i class="bi bi-trash"></i>
    </button>
</form>
<?php /**PATH E:\laragon\www\next-premiere\resources\views\admin\atlet\partials\actions.blade.php ENDPATH**/ ?>