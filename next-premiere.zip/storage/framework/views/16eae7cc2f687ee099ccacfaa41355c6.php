

<?php $__env->startSection('content'); ?>
    <div class="col-12">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <div class="row g-4">
            <div class="col-lg-6">
                <div class="card shadow-sm h-100">
                    <div class="card-header">
                        <h3 class="card-title mb-0">Profil</h3>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('admin.profile.update')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="mb-3">
                                <label for="name" class="form-label">Nama</label>
                                <input type="text" name="name" id="name" class="form-control"
                                    value="<?php echo e(old('name', $user->name)); ?>" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Email saat ini</label>
                                <input type="email" class="form-control" value="<?php echo e($user->email); ?>" disabled>
                            </div>
                            <button class="btn btn-primary" type="submit"><i class="bi bi-save me-1"></i>Simpan
                                Profil</button>
                        </form>
                    </div>
                </div>
            </div>

            <div class="col-lg-6">
                <div class="card shadow-sm h-100">
                    <div class="card-header">
                        <h3 class="card-title mb-0">Ganti Password</h3>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('admin.profile.password.update')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="mb-3"><label for="password" class="form-label">Password baru</label><input
                                    type="password" name="password" id="password" class="form-control" minlength="8"
                                    required></div>
                            <div class="mb-3"><label for="password_confirmation" class="form-label">Konfirmasi password
                                    baru</label><input type="password" name="password_confirmation"
                                    id="password_confirmation" class="form-control" minlength="8" required></div>
                            <button class="btn btn-primary" type="submit"><i class="bi bi-key me-1"></i>Ganti
                                Password</button>
                        </form>
                    </div>
                </div>
            </div>

            <div class="col-lg-6">
                <div class="card shadow-sm">
                    <div class="card-header">
                        <h3 class="card-title mb-0">Ganti Email</h3>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('admin.profile.email.otp')); ?>" method="POST" class="mb-4">
                            <?php echo csrf_field(); ?>
                            <label for="email" class="form-label">Email baru</label>
                            <div class="input-group"><input type="email" name="email" id="email"
                                    class="form-control" value="<?php echo e(old('email', $pendingEmail)); ?>" required><button
                                    class="btn btn-outline-primary" type="submit"><i class="bi bi-send me-1"></i>Kirim
                                    OTP</button></div>
                        </form>
                        <?php if($emailChangePending): ?>
                            <form action="<?php echo e(route('admin.profile.email.verify')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <label for="otp" class="form-label">Kode OTP</label>
                                <div class="input-group"><input type="text" name="otp" id="otp"
                                        class="form-control" inputmode="numeric" maxlength="6" pattern="[0-9]{6}"
                                        required><button class="btn btn-success" type="submit"><i
                                            class="bi bi-check2-circle me-1"></i>Verifikasi</button></div>
                                <small class="text-muted">Masukkan kode 6 digit yang dikirim ke email baru.</small>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\next-premiere\resources\views\admin\profile\index.blade.php ENDPATH**/ ?>