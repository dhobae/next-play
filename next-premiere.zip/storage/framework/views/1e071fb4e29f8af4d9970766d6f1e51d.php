

<?php $__env->startSection('content'); ?>
    <div class="col-12">
        <div class="card shadow-sm">
            <div class="card-header d-flex justify-content-between align-items-center">
                <div>
                    <h3 class="card-title mb-1">Edit Riwayat Turnamen</h3>
                    <div class="text-muted"><?php echo e($atlet->nama_atlet); ?></div>
                </div>
                
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('admin.atlet-riwayat.update', [$atlet, $riwayat])); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <?php echo $__env->make('admin.atlet-riwayat.partials.form', ['riwayat' => $riwayat], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="d-flex justify-content-end gap-2">
                        <a href="<?php echo e(route('admin.atlet-riwayat.manage', $atlet)); ?>"
                            class="btn btn-secondary btn-sm">Batal</a>
                        <button type="submit" class="btn btn-primary btn-sm">
                            <i class="bi bi-save me-1"></i> Simpan Perubahan
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\next-premiere\resources\views\admin\atlet-riwayat\edit.blade.php ENDPATH**/ ?>