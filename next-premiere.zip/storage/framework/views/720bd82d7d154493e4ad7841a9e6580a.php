

<?php $__env->startSection('content'); ?>
    <?php
        $hasHubungiKami = isset($hubungiKami);
        $isEditable = !$hasHubungiKami || $errors->any();
    ?>

    <div class="col-12">
        <div class="card shadow-sm">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h3 class="card-title mb-0">Hubungi Kami</h3>
            </div>
            <div class="card-body">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul class="mb-0">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form
                    action="<?php echo e($hasHubungiKami ? route('admin.hubungikami.update', $hubungiKami->id) : route('admin.hubungikami.store')); ?>"
                    method="POST">
                    <?php echo csrf_field(); ?>
                    <?php if($hasHubungiKami): ?>
                        <?php echo method_field('PUT'); ?>
                    <?php endif; ?>

                    <div class="mb-3">
                        <label for="link_wa" class="form-label">Link WhatsApp</label>
                        <input type="url" name="link_wa" id="link_wa" class="form-control"
                            value="<?php echo e(old('link_wa', $hubungiKami->link_wa ?? '')); ?>"
                            placeholder="https://wa.me/628xxxxxxxxxx" <?php echo e($isEditable ? '' : 'disabled'); ?> required>
                        <small class="text-muted">Masukkan link WhatsApp yang akan digunakan pengunjung.</small>
                        <?php $__errorArgs = ['link_wa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="d-block text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <?php if($hasHubungiKami): ?>
                        <button type="button" class="btn btn-warning btn-sm" id="editHubungiKami">
                            <i class="bi bi-pencil-square me-1"></i> Edit
                        </button>
                    <?php endif; ?>
                    <button type="submit" class="btn btn-primary btn-sm" id="saveHubungiKami" <?php echo e($isEditable ? '' : 'disabled'); ?>>
                        <i class="bi bi-save me-1"></i> Simpan
                    </button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php if($hasHubungiKami): ?>
        <script>
            document.getElementById('editHubungiKami').addEventListener('click', function() {
                document.getElementById('link_wa').disabled = false;
                document.getElementById('saveHubungiKami').disabled = false;
                document.getElementById('link_wa').focus();
                this.disabled = true;
            });
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\next-premiere\resources\views\admin\hubungikami\index.blade.php ENDPATH**/ ?>